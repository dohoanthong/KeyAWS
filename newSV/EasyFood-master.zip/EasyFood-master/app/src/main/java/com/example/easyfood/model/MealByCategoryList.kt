package com.example.easyfood.model

data class MealByCategoryList(
    val meals: List<MealByCategory>
)