package com.example.easyfood.model

data class MealByCategory(
    val idMeal: String,
    val strMeal: String,
    val strMealThumb: String
)