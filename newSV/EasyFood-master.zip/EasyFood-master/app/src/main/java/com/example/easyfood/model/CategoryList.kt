package com.example.easyfood.model

data class CategoryList(
    val categories: List<Category>
)