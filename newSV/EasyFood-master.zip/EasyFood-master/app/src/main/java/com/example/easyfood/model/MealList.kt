package com.example.easyfood.model

data class MealList(
    val meals: List<Meal>
)